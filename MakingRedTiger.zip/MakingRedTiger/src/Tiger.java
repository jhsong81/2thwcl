
public abstract class Tiger {
	protected String color;

	protected abstract void setColor(String color);

}
