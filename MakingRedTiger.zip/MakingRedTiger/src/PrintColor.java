
public interface PrintColor {
	public void printTigetColor();

}
